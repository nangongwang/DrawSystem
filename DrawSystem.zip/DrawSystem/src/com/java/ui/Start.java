package com.java.ui;

import com.cc.util.DrawFrame;

public class Start {
	
	public static void main(String[] args) {
		//实例化对象
		DrawFrame d = new DrawFrame();
		d.setVisible(true);
	}

}
